# -*- coding: utf-8 -*-
# @Time    : 2023/2/15 8:59
# @Author  : HongFei Wang
import datetime
import os
import time

import torch
from torch import optim
from config import config
from ulit import *
from torchvision.transforms import transforms as tf
from models import VGG19


def main():
	arg = config()
	print(arg)
	transform = {
		'train': tf.Compose([
			tf.ToTensor(),
			tf.Normalize(arg.mean, arg.std),
			tf.RandomRotation(90),
			tf.RandomVerticalFlip(),
			tf.RandomHorizontalFlip(),
			tf.ColorJitter(contrast=1)
		
		]),
		'test': tf.Compose([
			tf.ToTensor(),
			tf.Normalize(arg.mean, arg.std),
		])
	}
	model = VGG19(arg.num_classes).cuda()
	trainloader, testloader = getDataloader(arg, transform=transform)
	# mean_std(train_data=trainloader)
	lossFunction = torch.nn.CrossEntropyLoss()
	optimer = torch.optim.Adam(model.parameters(), lr=arg.lr, weight_decay=arg.weight_decay)
	scheduler = optim.lr_scheduler.MultiStepLR(optimer, [arg.epochs * 2 // 10, arg.epochs * 5 // 10])
	best = 0.
	os.makedirs('./log', exist_ok=True)
	os.makedirs('./checkpoint', exist_ok=True)
	
	timeArray = time.localtime(time.time())
	now = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
	print(now)
	now = now.replace(':', '.')
	f = open(f'./log/{now}.txt', 'w')
	f.write(f'epoch\ttrainLoss\ttestLoss\ttrainAcc\ttestAcc\tP\tR\tOA\tIou\tF1\n')
	f.close()
	for epoch in range(arg.epochs):
		f = open(f'./log/{now}.txt', 'a')
		tl, ta = train(trainloader, epoch, lossFunction, scheduler, model, optimer, best)
		vl, va, precision, recall, OA, IoU, f1ccore = Test(testloader, epoch, scheduler, model, best,
		              count=True, label=['COVID', 'Lung_Opacity', 'Normal', 'Viral Pneumonia'])
		scheduler.step()
		f.write(f'{epoch}\t{tl:.7f}\t{vl:.7f}\t{ta:.2f}\t{va:.2f}\t'
		        f'{precision}\t{recall}\t{OA}\t{IoU}\t{f1ccore}\n')
		f.close()
		if va > best:
			best = va
			torch.save(model.state_dict(), f'./checkpoint/{epoch + 1}.pth')


if __name__ == '__main__':
	main()
