import torch
from torchvision.models import vgg19_bn
import torch.nn as nn


class Convs(nn.Module):
	def __init__(self, ins, ous):
		super(Convs, self).__init__()
		self.conv = nn.Conv2d(ins, ous, 3, 1, 1)
		self.bn = nn.BatchNorm2d(ous)
		self.relu = nn.ReLU()
	
	def forward(self, x):
		x = self.bn(self.conv(x))
		return self.relu(x)


class VGG19(nn.Module):
	def __init__(self, numClass):
		super().__init__()
		self.conv1 = nn.Sequential(
		
		)
		self.conv1 = Convs(3, 64)
		self.conv2 = Convs(64, 64)
		self.conv3 = Convs(64, 128)
		self.conv4 = Convs(128, 128)
		self.conv5 = Convs(128, 256)
		self.conv6 = Convs(256, 256)
		self.conv7 = Convs(256, 256)
		self.conv8 = Convs(256, 256)
		self.conv9 = Convs(256, 512)
		self.conv10 = Convs(512, 512)
		self.conv11 = Convs(512, 512)
		self.conv12 = Convs(512, 512)
		self.conv13 = Convs(512, 512)
		self.conv14 = Convs(512, 512)
		self.conv15 = Convs(512, 512)
		self.conv16 = Convs(512, 512)
		self.pool5 = nn.MaxPool2d(kernel_size=2, stride=2)
		self.fc1 = nn.Linear(7 * 7 * 512, 4096)
		self.fc2 = nn.Linear(4096, 4096)
		self.fc3 = nn.Linear(4096, numClass)
		self.relu = nn.ReLU()
		self.pool = nn.MaxPool2d(2)
		#  # 迁移学习 调用官方方法
		# self.vgg = vgg19_bn(pretrained=False)
		# self.vgg.classifier._modules['6'] = nn.Linear(4096, numClass)
	
	def forward(self, x):
		x = self.relu(self.conv1(x))
		x = self.relu(self.conv2(x))
		x = self.pool(x)
		x = self.relu(self.conv3(x))
		x = self.relu(self.conv4(x))
		x = self.pool(x)
		x = self.relu(self.conv5(x))
		x = self.relu(self.conv6(x))
		x = self.relu(self.conv7(x))
		x = self.relu(self.conv8(x))
		x = self.pool(x)
		x = self.relu(self.conv9(x))
		x = self.relu(self.conv10(x))
		x = self.relu(self.conv11(x))
		x = self.relu(self.conv12(x))
		x = self.pool(x)
		x = self.relu(self.conv13(x))
		x = self.relu(self.conv14(x))
		x = self.relu(self.conv15(x))
		x = self.relu(self.conv16(x))
		x = self.pool(x)
		# x = x.view(x.size()[0], -1)
		x = x.view(-1, 7 * 7 * 512)
		x = self.relu(self.fc1(x))
		x = self.relu(self.fc2(x))
		x = self.fc3(x)
		# 迁移学习 调用官方方法 不适用 前面的注释
		# x = self.vgg(x)
		return x
