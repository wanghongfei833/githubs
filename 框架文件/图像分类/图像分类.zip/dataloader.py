# -*- coding: utf-8 -*-
# @Time    : 2023/2/16 8:57
# @Author  : HongFei Wang
import os
import sys
import random

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision.transforms import transforms

tfs = transforms.ToTensor()


class Datasets(Dataset):
	def __init__(self, root: str, model='train', transform=None, resize=False):
		super(Datasets, self).__init__()
		if root is None:
			print("输入文件夹目录")
			sys.exit()
		if model not in ['train', 'test']: raise print('only "train" or "test" ,but get %s' % model)
		self.root = root
		self.dir_root = os.path.dirname(__file__)
		self.to_tensor = transforms.ToTensor()
		if not os.path.isdir(self.root): raise print('input right filepath ,not %s' % self.root)
		self.modle = model
		self.image, self.lables = [], []
		names = self.root.replace('\\', '/').split('/')[-1]
		if not os.path.exists(f'{names}_train.txt') or not os.path.exists(f'{names}_test.txt'):
			self.read()
		
		if self.modle == 'train':
			datas = open(f'{names}_train.txt', "r")
			for line in datas.readlines():
				line = line.strip("\n")
				line = line.split("\t")
				self.image.append(line[0])
				self.lables.append(line[1])
		elif self.modle == 'test':
			datas = open(f'{names}_test.txt', "r")
			for line in datas.readlines():
				line = line.strip("\n")
				line = line.split("\t")
				self.image.append(line[0])
				self.lables.append(line[1])
		
		self.transform = transform
		if resize:
			if type(resize) == tuple:
				self.resizes = resize
			elif type(resize) == int:
				self.resizes = (resize, resize)
		else:
			self.resizes = resize
	
	def __getitem__(self, idx):
		image, labels = self.image[idx], int(self.lables[idx])
		image = Image.open(image).convert("RGB")
		if self.transform: image = self.transform(image)
		labers = torch.tensor(labels)
		
		return image, labers
	
	def __len__(self):
		return len(self.image)
	
	
	def read(self):
		# 判断文件是否存在。不存在就创建
		names = self.root.replace('\\', '/').split('/')[-1]
		f1 = open(f'{names}_train.txt', "w")
		f2 = open(f'{names}_test.txt', "w")
		for index, paths in enumerate(sorted(os.listdir(self.root))):
			paths_ = os.path.join(self.root, paths)
			dirs = os.listdir(paths_)
			random.shuffle(dirs)
			cat = int(len(dirs) * 0.8)
			for pata_file in dirs[:cat]:  # 写入训练集
				try:
					f1.write(os.path.join(paths_, pata_file) + '\t' + str(index) + '\n')
				except:
					print(os.path.join(paths_, pata_file) + '\t' + str(index))
			for pata_file in dirs[cat:]:  # 写入测试集
				f2.write(os.path.join(paths_, pata_file) + '\t' + str(index) + '\n')
		f1.close()
		f2.close()
		print('数据集创建成功，请重新运行!!!')
		sys.exit()
